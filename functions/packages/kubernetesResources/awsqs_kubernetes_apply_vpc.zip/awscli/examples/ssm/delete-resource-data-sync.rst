**To delete a resource data sync**

This example deletes a resource data sync. There is no output if the command succeeds.

Command::

  aws ssm delete-resource-data-sync --sync-name "ssm-resource-data-sync"
